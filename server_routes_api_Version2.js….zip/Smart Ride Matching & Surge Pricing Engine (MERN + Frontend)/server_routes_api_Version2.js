const express = require('express');
const { v4: uuidv4 } = require('uuid');

const Driver = require('../models/Driver');
const RideRequest = require('../models/RideRequest');
const surgeEngine = require('../core/surge');
const { matchGreedy } = require('../core/matchmaking');

const router = express.Router();

// Driver heartbeat: create or update driver
router.post('/driver/heartbeat', async (req, res) => {
  try {
    const { driverId, lat, lon, status } = req.body;
    if (!driverId || lat === undefined || lon === undefined) {
      return res.status(400).json({ error: 'driverId, lat, lon required' });
    }
    const update = {
      location: { type: 'Point', coordinates: [lon, lat] },
      status: status || 'available',
      updatedAt: new Date()
    };
    const driver = await Driver.findOneAndUpdate({ driverId }, { $set: update }, { upsert: true, new: true });
    return res.json({ ok: true, driver });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'server_error' });
  }
});

// Create ride request -> match
router.post('/ride/request', async (req, res) => {
  try {
    const { riderId, origin, destination, seats, regionId } = req.body;
    if (!origin || origin.lat === undefined || origin.lon === undefined) {
      return res.status(400).json({ error: 'origin required' });
    }
    const requestId = uuidv4();
    const rr = await RideRequest.create({
      requestId,
      riderId,
      origin,
      destination,
      seats: seats || 1
    });

    // Simple region-based counts for surge (single region if provided)
    const region = regionId || 'default';
    const demand = 1;
    const supply = await Driver.countDocuments({ status: 'available' });
    surgeEngine.updateCounts(region, demand, supply);
    const multiplier = surgeEngine.getMultiplier(region);

    // Find candidate drivers (simple radius query using Mongo geospatial if data present)
    // For prototype: find up to 50 nearest available drivers (coarse)
    const drivers = await Driver.find({
      status: 'available',
      location: {
        $near: {
          $geometry: { type: "Point", coordinates: [origin.lon, origin.lat] },
          $maxDistance: 20000
        }
      }
    }).limit(50).lean();

    // fallback: if no drivers returned, fetch any available drivers
    const candidates = (drivers && drivers.length) ? drivers : await Driver.find({ status: 'available' }).limit(100).lean();

    const best = matchGreedy(origin, candidates);
    if (best) {
      // assign (note: race conditions possible; for production use atomic lock)
      await Driver.updateOne({ driverId: best.driverId, status: 'available' }, { $set: { status: 'on_trip' } });
      rr.assignedDriverId = best.driverId;
      rr.status = 'matched';
      await rr.save();
    }

    return res.status(202).json({
      requestId,
      matchedDriver: best ? { driverId: best.driverId } : null,
      surgeMultiplier: multiplier
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'server_error' });
  }
});

// Get multiplier for a region
router.get('/surge/:regionId', (req, res) => {
  const region = req.params.regionId || 'default';
  const mul = surgeEngine.getMultiplier(region);
  res.json({ region, multiplier: mul });
});

module.exports = router;